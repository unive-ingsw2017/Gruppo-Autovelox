package it.unive.dais.cevid.datadroid.lib.parser;

import java.io.IOException;

/**
 * Created by spano on 11/01/2018.
 */
public class ParserException extends IOException {
    public ParserException(String s) {
        super(s);
    }
}
